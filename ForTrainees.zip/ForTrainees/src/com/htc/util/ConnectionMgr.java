package com.htc.util;

import java.io.FileInputStream;
import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.Properties;

public class  ConnectionMgr {
	static Connection con=null;
	static Properties jdbcconfig=null;
	static Connection getConnection() throws IOException,ClassNotFoundException,SQLException
	{
		
		
		jdbcconfig=new Properties(); 
		FileInputStream propobj=new FileInputStream("config.properties");
		jdbcconfig.load(propobj);
		 String driver = jdbcconfig.getProperty("postgres.driver");
	        if (driver != null) {
	            Class.forName(driver) ;
	        }

	        String url = jdbcconfig.getProperty("postgres.url");
	        String username = jdbcconfig.getProperty("postgres.username");
	        String password = jdbcconfig.getProperty("postgres.password");
	        con =DriverManager.getConnection(url, username, password);
		return con;
		
	}

}
