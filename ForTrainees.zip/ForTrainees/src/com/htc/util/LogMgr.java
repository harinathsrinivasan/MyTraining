package com.htc.util;

public class LogMgr {

}
