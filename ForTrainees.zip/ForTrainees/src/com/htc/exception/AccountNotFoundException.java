package com.htc.exception;

public class AccountNotFoundException extends NullPointerException{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	private String msg;

	public AccountNotFoundException() {
		super();
		// TODO Auto-generated constructor stub
	}

	public AccountNotFoundException(String s) {
		super(s);
		// TODO Auto-generated constructor stub
	}

	@Override
	public String toString() {
		return "AccountNotFoundException [msg=" + msg + "]";
	}
	

}
