package com.htc.exception;

public class CustomerNotFoundException extends NullPointerException {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	/**
	 * 
	 */
	
	private String msg;

	public CustomerNotFoundException() {
		super();
		// TODO Auto-generated constructor stub
	}

	public CustomerNotFoundException(String msg) {
		super();
		this.msg = msg;
	}

	@Override
	public String toString() {
		return "CustomerNotFoundException [msg=" + msg + "]";
	}
	
	
	
}
