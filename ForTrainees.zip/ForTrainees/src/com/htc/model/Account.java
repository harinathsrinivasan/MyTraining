package com.htc.model;

public class Account {
	private String accountNo;
	private String accountName;
	private double balance=1000;
		Account(String accountName,String accountNo)
		{
			this.accountNo=accountNo;
			this.accountName=accountName;
		}
		public String getAccountName() {
			return accountName;
		}
		public void setAccountName(String accountName) {
			this.accountName = accountName;
		}
		public String getAccountNo() {
			return accountNo;
		}
		public void setAccountNo(String accountNo) {
			this.accountNo = accountNo;
		}
		public double getBalance() {
			return balance;
		}
		public void setBalance(double balance) {
			this.balance = balance;
		}
}
