package com.htc.dao;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import com.htc.exception.CustomerNotFoundException;
import com.htc.model.Customer;

public class ColCustomerService implements ICustomerService{

	static List<Customer> customerRepo=new ArrayList<>();
	
	@Override
	public boolean createCustomer(Customer cus) {
		// TODO Auto-generated method stub
		boolean status=false;
		customerRepo.add(cus);
		if(customerRepo.contains(cus))
		{
			status=true;
		}
		return status;
	}

	@Override
	public boolean updateCustomer(Customer cus) {
		// TODO Auto-generated method stub
		
		boolean status=false;
		for(Customer element:customerRepo)
		{
			if(element.getId()==cus.getId())
			{
			customerRepo.add(cus);
			}
		}
		
		if(customerRepo.equals(cus))
		{
			status=true;
		}
		return status;
	}

	@Override
	public boolean deleteCustomer(long id) {

		boolean status=true;
		Iterator<Customer> cusItr=customerRepo.iterator();
		while(cusItr.hasNext())
		{
			if(cusItr.next().getId()==id)
			{
				
				cusItr.remove();
			}
		}
		
	
		for(Customer element:customerRepo)
		{
			if(element.getId()==id)
			{
			status=false;
			break;
			}
		}
		
		return status;
	}

	@Override
	public Customer getCustomerByid(long id) throws CustomerNotFoundException {
		// TODO Auto-generated method stub
		Customer obj=null;
		for(Customer element:customerRepo)
		{
			if(element.getId()==id)
			{
			obj=element;
			}
		}
		
		return obj;
	}

	@Override
	public Customer getCustomerBymobileno(long no) throws CustomerNotFoundException {
		// TODO Auto-generated method stub
		Customer obj=null;
		for(Customer element:customerRepo)
		{
			if(element.getId()==no)
			{
			obj=element;
			}
		}
		
		return obj;
	}

	@Override
	public List<Customer> searchCustomersByname(String name) throws CustomerNotFoundException {
		// TODO Auto-generated method stub
		List<Customer> result =new ArrayList<>();
		
		
		for(Customer element:customerRepo)
		{
			if(element.getName().contains(name))
			{
			result.add(element);
			}
		}
		
		return result;
	}

}
