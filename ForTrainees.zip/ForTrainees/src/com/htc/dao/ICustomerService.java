package com.htc.dao;

import java.util.List;

import com.htc.model.Customer;

public interface ICustomerService {

	boolean createCustomer(Customer cus);
	boolean updateCustomer(Customer cus);
	boolean deleteCustomer(long id);
	Customer getCustomerByid(long id);
	Customer getCustomerBymobileno(long no);
	List<Customer> searchCustomersByname(String name);
	//inFuture
	//List<Customer>searchCustomerBynameAndLocation(Customer cus);
	
}
