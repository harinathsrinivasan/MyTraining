package com.htc.dao;

import com.htc.model.Account;
import com.htc.model.Customer;

public interface IAccountService {
	
	boolean createAccount(Account acc,Customer cus);
	boolean updateAccount(Account acc);
	boolean deleteAccount(Account acc);
	boolean getAccountByid(Account acc);
	boolean getAccountByDetails(Account acc);

}
