package com.htc.dao;

import com.htc.model.Account;
import com.htc.model.Customer;

public class colAccountService  implements IAccountService{
 
	@Override
	public boolean createAccount(Account acc,Customer cus) {
		// TODO Auto-generated method stub
		
		return false;
	}

	@Override
	public boolean updateAccount(Account acc) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public boolean deleteAccount(Account acc) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public boolean getAccountByid(Account acc) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public boolean getAccountByDetails(Account acc) {
		// TODO Auto-generated method stub
		return false;
	}

}
