{'name': 'To-do Tasks Management Assistant',
 'description': 'Mass edit your To-Do backlog.',
 'author': 'Daniel Reis',
 'depends': ['todo_app'],
 'data': [
     'views/todo_wizard_view.xml',
 ], }
