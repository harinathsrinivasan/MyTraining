sudo apt-get install openssh-server
ip addr show  # check your IP address
whoami  # check your user name
echo $HOME  # check your home directory path
